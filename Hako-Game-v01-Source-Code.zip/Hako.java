/**
 * Hako: a game where you move boxes
 * 
 * @author Allen Mitro
 * @version v.0.1-alpha
 */
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import java.util.ArrayList;
import java.io.InputStream;
public class Hako
{
    static HakoGUI mygui = new HakoGUI();
    static char wallchar = '\uFFE6',boxchar = '\uff22',occupychar='\uff42',spacechar = '\u3000',goalchar = '\uff27',charchar = '\uff20';
    static int ux = -1,uy = -1,currentlevel=0,movecount =0;
    static ArrayList<ArrayList<String>> level = new ArrayList(0);
    static ArrayList<String> everylevel = new ArrayList(0);
    static ArrayList<int []> goals = new ArrayList(0);
    public static void main(String[] args)
    {
        mygui.setVisible(true);
        try
        {
            ClassLoader classLoad = Thread.currentThread().getContextClassLoader();
            InputStream stream = classLoad.getResource("file.txt").openStream(); 
            everylevel = parse(Stream2String(stream),'L');
        }
        catch(IOException e)
        {
            HakoGUI.status.setText("Read error.");
        }
        reset();
        HakoGUI.board.setText(makeboard(level));
        mygui.pack();
    }

    public static String Stream2String(java.io.InputStream is) 
    {
        java.util.Scanner s = new java.util.Scanner(is).useDelimiter("\\A");
        return s.hasNext() ? s.next() : "";
    }

    public static ArrayList<String> parse(String parseThis,char delimiter)
    {
        int width = 0,elements = 0,temp = 0;

        for(int a = 0; a < parseThis.length();a++)//check the first row to see what the dimension should be
        {
            if(parseThis.charAt(a) == delimiter)
            {
                width++;
            }
        }

        ArrayList<String> toR = new ArrayList<String>();

        if(width==0)
        {
            toR.add(parseThis);
            return toR;
        }

        width++;

        for(int b = 0;elements<width;b++)
        {
            if(elements>=width-1)//if last element copy the rest
            {
                toR.add(parseThis.substring(temp));
                break;
            }

            if(b>=parseThis.length())//if we are at the end of the line before all the elements filled
            {
                while(elements<width)
                {
                    toR.add("");//just fill it with blank then
                    elements++;
                }

                break;
            }

            if(parseThis.charAt(b)==delimiter)//delimiter is the comma
            {
                toR.add(parseThis.substring(temp,b));//set the former stuff to the element
                temp = b+1;//shorten the string we have to work with
                elements++;//go to next element
            }
        }

        return toR;
    }

    public static String makeboard(ArrayList<ArrayList<String>> show)
    {
        HakoGUI.option.setText("moves: "+movecount);
        HakoGUI.levelcount.setText("Level: "+(currentlevel+1));
        String toR = "";
        for(int a = 0;a<show.size();a++)
        {
            for(int b = 0;b<show.get(a).size();b++)
            {
                boolean goalhere = false;
                for(int c = 0;c<goals.size();c++)
                    if(goals.get(c)[1]==a&&goals.get(c)[0]==b)
                        goalhere = true;
                if(show.get(a).get(b).charAt(0)=='u'&&ux ==-1)
                {
                    uy = a;
                    ux = b;
                }
                if(uy==a&&ux==b)
                {
                    toR+=""+charchar;
                }
                else if(show.get(a).get(b).charAt(0)=='w')
                    toR+=""+wallchar;
                else if(goalhere&&show.get(a).get(b).charAt(0)=='b')
                    toR+=""+occupychar;
                else if(show.get(a).get(b).charAt(0)=='b')
                    toR+=""+boxchar;
                else if(show.get(a).get(b).charAt(0)=='g')
                    toR+=goalchar+"";
                else 
                    toR+=""+spacechar;
            }
            toR +="\n";
        }
        return toR;
    }

    public static void reset()
    {
        level = new ArrayList(0);
        ArrayList<String> temp;
        temp = parse(everylevel.get(currentlevel),'\n');
        for(int a = 0;a<temp.size();a++)
            level.add(parse(temp.get(a),','));
        goals = new ArrayList(0);
        for(int a = 0;a<level.size();a++)
            for(int b = 0;b<level.get(a).size();b++)
                if(level.get(a).get(b).charAt(0)=='g')
                    goals.add(new int[]{b,a});
                else if(level.get(a).get(b).charAt(0)=='P')
                {
                    goals.add(new int[]{b,a});
                    level.get(a).set(b,"b");
                }
        movecount =0;
    }
}
class HakoGUI extends JFrame
{
    protected static JPanel content = new JPanel (),leveloption = new JPanel();
    protected static JPanel buttons = new JPanel (),leftpanel = new JPanel();
    protected static JTextArea board = new JTextArea (16,16);
    protected static JLabel status = new JLabel ("Welcome!"),option = new JLabel("Move: "),levelcount = new JLabel("Level: ");
    protected static JButton up = new JButton("^"),down = new JButton("v"),left = new JButton("<"),right = new JButton(">"),reset = new JButton("reset"),next = new JButton ("Next Level"), prev = new JButton("Prev. Level");;
    public HakoGUI()
    {
        buttons.setLayout(new GridLayout(2,3));
        leftpanel.setLayout(new GridLayout(3,1));
        leveloption.setLayout(new GridLayout(1,3));

        buttons.add(levelcount);
        buttons.add(up);
        buttons.add(option);
        buttons.add(left);
        buttons.add(down);
        buttons.add(right);
        leftpanel.add(new JLabel("Hako Game - Allen Mitro"));
        leftpanel.add(leveloption);
        leftpanel.add(buttons);
        leveloption.add(prev);
        leveloption.add(reset);
        leveloption.add(next);

        up.addActionListener (new LisBtn2());
        down.addActionListener (new LisBtn2());
        left.addActionListener (new LisBtn2());
        right.addActionListener (new LisBtn2());
        reset.addActionListener (new LisBtn2());
        prev.addActionListener (new LisBtn2());
        next.addActionListener(new LisBtn2());
        board.addKeyListener(new key_Listen());

        board.setFont(new Font(Font.SANS_SERIF,0,16));
        board.setForeground(Color.GREEN);
        board.setBackground(Color.BLACK);

        content.setLayout(new BorderLayout());
        content.add(board,BorderLayout.CENTER);
        content.add(leftpanel,BorderLayout.LINE_START);
        content.add(status,BorderLayout.PAGE_END);
        setContentPane(content);
        pack();
        setTitle("Hako Game");
        setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo (null);           // Center window.
    }

}
class LisBtn2 implements ActionListener
{
    public void actionPerformed(ActionEvent e)
    {//activates buttons sort and flip
        HakoGUI.status.setText("");
        if(((JButton)e.getSource()).getText().equals("^"))
        {
            try
            {
                char move = Hako.level.get(Hako.uy-1).get(Hako.ux).charAt(0);
                if(pass(move))
                {
                    Hako.uy--; Hako.movecount++;
                }
                else if(move=='b'&&pass(Hako.level.get(Hako.uy-2).get(Hako.ux).charAt(0)))
                {
                    Hako.level.get(Hako.uy-1).set(Hako.ux," ");
                    Hako.level.get(Hako.uy-2).set(Hako.ux,"b");
                    Hako.uy--; Hako.movecount++;
                }
                else
                {
                    HakoGUI.status.setText("You can't move that.");
                }
                HakoGUI.board.setText(Hako.makeboard(Hako.level));
            }
            catch (Exception ex)
            {
                HakoGUI.status.setText("That leads outside");
            }
        }
        if(((JButton)e.getSource()).getText().equals("v"))
        {
            try
            {
                char move = Hako.level.get(Hako.uy+1).get(Hako.ux).charAt(0);
                if(pass(move))
                {
                    Hako.uy++; Hako.movecount++;
                }
                else if(move=='b'&&pass(Hako.level.get(Hako.uy+2).get(Hako.ux).charAt(0)))
                {
                    Hako.level.get(Hako.uy+1).set(Hako.ux," ");
                    Hako.level.get(Hako.uy+2).set(Hako.ux,"b");
                    Hako.uy++; Hako.movecount++;
                }
                else
                {
                    HakoGUI.status.setText("You can't move that.");
                }
                HakoGUI.board.setText(Hako.makeboard(Hako.level));
            }
            catch (Exception ex)
            {
                HakoGUI.status.setText("That leads outside");
            }
        }
        if(((JButton)e.getSource()).getText().equals("<"))
        {
            try
            {
                char move = Hako.level.get(Hako.uy).get(Hako.ux-1).charAt(0);
                if(pass(move))
                {
                    Hako.ux--; Hako.movecount++;
                }
                else if(move=='b'&&pass(Hako.level.get(Hako.uy).get(Hako.ux-2).charAt(0)))
                {
                    Hako.level.get(Hako.uy).set(Hako.ux-1," ");
                    Hako.level.get(Hako.uy).set(Hako.ux-2,"b");
                    Hako.ux--; Hako.movecount++;
                }
                else
                {
                    HakoGUI.status.setText("You can't move that.");
                }
                HakoGUI.board.setText(Hako.makeboard(Hako.level));
            }
            catch (Exception ex)
            {
                HakoGUI.status.setText("That leads outside");
            }
        }
        if(((JButton)e.getSource()).getText().equals(">"))
        {
            try
            {
                char move = Hako.level.get(Hako.uy).get(Hako.ux+1).charAt(0);
                if(pass(move))
                {
                    Hako.ux++; Hako.movecount++;
                }
                else if(move=='b'&&pass(Hako.level.get(Hako.uy).get(Hako.ux+2).charAt(0)))
                {
                    Hako.level.get(Hako.uy).set(Hako.ux+1," ");
                    Hako.level.get(Hako.uy).set(Hako.ux+2,"b");
                    Hako.ux++; Hako.movecount++;
                }
                else
                {
                    HakoGUI.status.setText("You can't move that.");
                }
                HakoGUI.board.setText(Hako.makeboard(Hako.level));
            }
            catch (Exception ex)
            {
                HakoGUI.status.setText("That leads outside");
            }
        }
        if(((JButton)e.getSource()).getText().equals("reset"))
        {
            Hako.ux=-1;
            Hako.reset();
            HakoGUI.board.setText(Hako.makeboard(Hako.level));
        }
        if(((JButton)e.getSource()).getText().equals("Prev. Level"))
        {
            Hako.ux=-1;
            if(Hako.currentlevel>1)
                Hako.currentlevel--;
            Hako.reset();
            HakoGUI.board.setText(Hako.makeboard(Hako.level));
        }
        if(((JButton)e.getSource()).getText().equals("Next Level"))
        {
            Hako.ux=-1;
            if(Hako.currentlevel<58)
            {
                Hako.currentlevel++;
                Hako.reset();
                HakoGUI.board.setText(Hako.makeboard(Hako.level));
            }
            else
            {
                Hako.goals = new ArrayList(0);
            }
        }
        for(int a = 0;a<Hako.goals.size();a++)
            if(Hako.level.get(Hako.goals.get(a)[1]).get(Hako.goals.get(a)[0]).charAt(0)!='b')
                Hako.level.get(Hako.goals.get(a)[1]).set(Hako.goals.get(a)[0],"g");
            else
                Hako.level.get(Hako.goals.get(a)[1]).set(Hako.goals.get(a)[0],"b");

        boolean temp = false;
        for(int a = 0;a<Hako.level.size();a++)
            for(int b = 0;b<Hako.level.get(a).size();b++)
                if(Hako.level.get(a).get(b).charAt(0)=='g')
                {
                    temp = true;
                    break;
                }

        if(!temp)
        {
            HakoGUI.status.setText("You've passed the level.");
            Hako.ux=-1;
            Hako.currentlevel++;
            if(Hako.currentlevel<60)
            {
                Hako.reset();
                HakoGUI.board.setText(Hako.makeboard(Hako.level));
            }
            else
                HakoGUI.board.setText("You've passed all the levels!\nCongratulations!!!\n\nOr did you just press next level many times?");
        }
    }

    public boolean pass(char check)
    {
        if(check=='w'||check=='b')
        {
            return false;
        }
        return true;
    }
}

class key_Listen implements KeyListener
{
    public void keyReleased(KeyEvent e){}

    public void keyTyped(KeyEvent e){}

    public void keyPressed(KeyEvent e) 
    {
        HakoGUI.status.setText("");
        int key = e.getKeyCode();

        if (key == KeyEvent.VK_LEFT) 
        {
            try
            {
                char move = Hako.level.get(Hako.uy).get(Hako.ux-1).charAt(0);
                if(pass(move))
                {
                    Hako.ux--; Hako.movecount++;
                }
                else if(move=='b'&&pass(Hako.level.get(Hako.uy).get(Hako.ux-2).charAt(0)))
                {
                    Hako.level.get(Hako.uy).set(Hako.ux-1," ");
                    Hako.level.get(Hako.uy).set(Hako.ux-2,"b");
                    Hako.ux--; Hako.movecount++;
                }
                else
                {
                    HakoGUI.status.setText("You can't move that.");
                }
                HakoGUI.board.setText(Hako.makeboard(Hako.level));
            }
            catch (Exception ex)
            {
                HakoGUI.status.setText("That leads outside");
            }
        }

        if (key == KeyEvent.VK_RIGHT) 
        {
            try
            {
                char move = Hako.level.get(Hako.uy).get(Hako.ux+1).charAt(0);
                if(pass(move))
                {
                    Hako.ux++; Hako.movecount++;
                }
                else if(move=='b'&&pass(Hako.level.get(Hako.uy).get(Hako.ux+2).charAt(0)))
                {
                    Hako.level.get(Hako.uy).set(Hako.ux+1," ");
                    Hako.level.get(Hako.uy).set(Hako.ux+2,"b");
                    Hako.ux++; Hako.movecount++;
                }
                else
                {
                    HakoGUI.status.setText("You can't move that.");
                }
                HakoGUI.board.setText(Hako.makeboard(Hako.level));
            }
            catch (Exception ex)
            {
                HakoGUI.status.setText("That leads outside");
            }
        }

        if (key == KeyEvent.VK_UP) 
        {
            try
            {
                char move = Hako.level.get(Hako.uy-1).get(Hako.ux).charAt(0);
                if(pass(move))
                {
                    Hako.uy--; Hako.movecount++;
                }
                else if(move=='b'&&pass(Hako.level.get(Hako.uy-2).get(Hako.ux).charAt(0)))
                {
                    Hako.level.get(Hako.uy-1).set(Hako.ux," ");
                    Hako.level.get(Hako.uy-2).set(Hako.ux,"b");
                    Hako.uy--; Hako.movecount++;
                }
                else
                {
                    HakoGUI.status.setText("You can't move that.");
                }
                HakoGUI.board.setText(Hako.makeboard(Hako.level));
            }
            catch (Exception ex)
            {
                HakoGUI.status.setText("That leads outside");
            }
        }

        if (key == KeyEvent.VK_DOWN) 
        {
            try
            {
                char move = Hako.level.get(Hako.uy+1).get(Hako.ux).charAt(0);
                if(pass(move))
                {
                    Hako.uy++; Hako.movecount++;
                }
                else if(move=='b'&&pass(Hako.level.get(Hako.uy+2).get(Hako.ux).charAt(0)))
                {
                    Hako.level.get(Hako.uy+1).set(Hako.ux," ");
                    Hako.level.get(Hako.uy+2).set(Hako.ux,"b");
                    Hako.uy++; Hako.movecount++;
                }
                else
                {
                    HakoGUI.status.setText("You can't move that.");
                }
                HakoGUI.board.setText(Hako.makeboard(Hako.level));
            }
            catch (Exception ex)
            {
                HakoGUI.status.setText("That leads outside");
            }
        }
        if (key == KeyEvent.VK_R) 
        {
            Hako.ux=-1;
            Hako.reset();
            HakoGUI.board.setText(Hako.makeboard(Hako.level));
        }
        for(int a = 0;a<Hako.goals.size();a++)
            if(Hako.level.get(Hako.goals.get(a)[1]).get(Hako.goals.get(a)[0]).

            charAt(0)!='b')
                Hako.level.get(Hako.goals.get(a)[1]).
                set(Hako.goals.get(a)[0],"g");
            else
                Hako.level.get(Hako.goals.get(a)[1]).set(Hako.goals.get(a)[0],"b");

        boolean temp = false;
        for(int a = 0;a<Hako.level.size();a++)
            for(int b = 0;b<Hako.level.get(a).size();b++)
                if(Hako.level.get(a).
                get(b).

                charAt(0)=='g')
                {
                    temp = true;
                    break;
                }

        if(!temp)
        {
            HakoGUI.status.setText("You've passed the level.");
            Hako.ux=-1;
            Hako.currentlevel++;
            Hako.reset();
            HakoGUI.board.setText(Hako.makeboard(Hako.level));
        }
    }

    public boolean pass(char check)
    {
        if(check=='w'||check=='b')
        {
            return false;
        }
        return true;
    }
}
